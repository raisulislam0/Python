import re
import sys
import difflib
import os

# Define paths relative to the script's location
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))  # Root directory of the script
SOURCE_FILE = os.path.join(ROOT_DIR, "src", "apidoc-doxy.cpp")  # Path to source.cpp
APIDOC_FILE = os.path.join(ROOT_DIR, "doc_container", "_apidoc.js")  # Path to _apidoc.js

def normalize_line(line):
    """Normalize a single line by removing leading/trailing whitespace and asterisks."""
    return re.sub(r'^\s*\*?\s*', '', line).rstrip()

def normalize_apidoc_block(block):
    """Normalize an APIDoc block by removing extra whitespace and formatting."""
    lines = []
    for line in block.split('\n'):
        cleaned_line = normalize_line(line)
        
        # Skip empty lines
        if not cleaned_line:
            continue
            
        # Only keep lines that are part of APIDoc (starting with @api)
        if cleaned_line.startswith('@api'):
            lines.append(cleaned_line)
    
    return '\n'.join(lines)

def compare_versions(version1, version2):
    """Compare two semantic versions without external dependencies."""
    if version1 == version2:
        return 0
        
    v1_parts = [int(x) for x in version1.split('.')]
    v2_parts = [int(x) for x in version2.split('.')]
    
    while len(v1_parts) < 3:
        v1_parts.append(0)
    while len(v2_parts) < 3:
        v2_parts.append(0)
        
    for i in range(3):
        if v1_parts[i] > v2_parts[i]:
            return 1
        elif v1_parts[i] < v2_parts[i]:
            return -1
            
    return 0

def is_version_greater(version1, version2):
    """Check if version1 is greater than version2."""
    try:
        return compare_versions(version1, version2) > 0
    except ValueError:
        return False

def extract_api_info(block, file_path, line_number=None):
    """Extract API information from a documentation block."""
    api_info = {
        'method': None,
        'path': None,
        'name': None,
        'group': None,
        'version': None,
        'normalized_block': normalize_apidoc_block(block),
        'raw_block': block,
        'file_path': file_path,
        'line_number': line_number,
        'missing_fields': []
    }
    
    api_lines = [normalize_line(line) for line in block.split('\n') 
                if normalize_line(line).startswith('@api')]
    api_info['api_lines'] = api_lines
    
    api_endpoint_found = False
    for line in api_lines:
        if line.startswith('@api '):
            match = re.search(r'@api\s+\{([^}]+)\}\s+([^\s]+)', line)
            if match:
                api_info['method'] = match.group(1).lower().strip()
                api_info['path'] = match.group(2).strip()
                api_endpoint_found = True
                break
    
    if not api_endpoint_found:
        api_info['missing_fields'].append('@api')
    
    api_name_found = False
    for line in api_lines:
        if line.startswith('@apiName '):
            match = re.search(r'@apiName\s+(\S+)', line)
            if match:
                api_name = match.group(1).strip()
                if api_name:
                    api_info['name'] = api_name
                    api_name_found = True
                break
    
    if not api_name_found:
        api_info['missing_fields'].append('@apiName')
    
    api_group_found = False
    for line in api_lines:
        if line.startswith('@apiGroup '):
            match = re.search(r'@apiGroup\s+(\S+)', line)
            if match:
                api_group = match.group(1).strip()
                if api_group:
                    api_info['group'] = api_group
                    api_group_found = True
                break
    
    if not api_group_found:
        api_info['missing_fields'].append('@apiGroup')
    
    api_version_found = False
    for line in api_lines:
        if line.startswith('@apiVersion '):
            match = re.search(r'@apiVersion\s+(\d+\.\d+\.\d+)', line)
            if match:
                api_version = match.group(1).strip()
                if api_version:
                    api_info['version'] = api_version
                    api_version_found = True
                break
    
    if not api_version_found:
        api_info['missing_fields'].append('@apiVersion')
    
    return api_info

def get_api_identifier(api_info):
    """Create a unique identifier for an API."""
    return (api_info['name'], api_info['group'])

def extract_apidoc_blocks(file_path):
    """Extract all APIDoc blocks from a file with line numbers."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"Error opening file {file_path}: {e}")
        return {}
    
    matches = list(re.finditer(r'/\*\*([\s\S]*?)\*/', content))
    api_docs = {}
    for match in matches:
        block = match.group(1)
        line_count = content[:match.start()].count('\n') + 1
        
        if not re.search(r'@api\b', block):
            continue
        
        api_info = extract_api_info(block, file_path, line_number=line_count)
        
        if api_info['name'] and api_info['group']:
            api_identifier = get_api_identifier(api_info)
            if api_identifier not in api_docs:
                api_docs[api_identifier] = []
            api_docs[api_identifier].append(api_info)
    
    return api_docs

def format_api_identifier(identifier):
    """Format an API identifier as a readable string."""
    name, group = identifier
    parts = []
    if name:
        parts.append(f"Name: {name}")
    if group:
        parts.append(f"Group: {group}")
    return " | ".join(parts) or "Unknown API"

def compare_api_blocks(source_block, apidoc_block):
    """Compare two API blocks line by line."""
    source_lines = sorted(source_block['api_lines'])
    apidoc_lines = sorted(apidoc_block['api_lines'])
    return source_lines == apidoc_lines

def check_empty_fields(api_info):
    """Check if any mandatory fields are empty."""
    errors = []
    if not api_info['method']:
        errors.append("@api method is empty")
    if not api_info['path']:
        errors.append("@api path is empty")
    if not api_info['name']:
        errors.append("@apiName is empty")
    if not api_info['group']:
        errors.append("@apiGroup is empty")
    if not api_info['version']:
        errors.append("@apiVersion is empty")
    return errors

def get_highest_version_for_api(api_id, api_infos):
    """Get the highest version for a specific API endpoint."""
    highest_version = "0.0.0"
    for api_info in api_infos:
        if api_info['version'] and is_version_greater(api_info['version'], highest_version):
            highest_version = api_info['version']
    return highest_version

def preliminary_empty_check(file_path):
    """Perform a preliminary check for empty mandatory values in the source file."""
    print(f"Performing preliminary check for empty mandatory values in {file_path}...")
    errors = []
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"Error opening file {file_path}: {e}")
        sys.exit(1)
    
    matches = list(re.finditer(r'/\*\*([\s\S]*?)\*/', content))
    
    for match in matches:
        block = match.group(1)
        if not re.search(r'@api\b', block):
            continue
        
        line_number = content[:match.start()].count('\n') + 1
        api_info = extract_api_info(block, file_path, line_number)
        empty_fields = check_empty_fields(api_info)
        
        if empty_fields:
            api_desc = format_api_identifier(get_api_identifier(api_info))
            location = f" at line {line_number}"
            errors.append(
                f"API {api_desc}{location} has empty mandatory fields: {', '.join(empty_fields)}"
            )
    
    if errors:
        print("\n=== PRELIMINARY CHECK FAILED ===")
        for i, error in enumerate(errors):
            print(f"Error {i+1}: {error}")
        print("\nExecution stopped due to empty mandatory values in source file.")
        sys.exit(1)
    else:
        print("Preliminary check passed: No empty mandatory values found.")
    return True

def check_for_duplicate_versions(source_docs, apidoc_docs):
    # [Remaining function unchanged]
    errors = []
    for api_id, source_apis in source_docs.items():
        if api_id not in apidoc_docs:
            continue
        existing_versions = set(api_info['version'] for api_info in apidoc_docs[api_id] if api_info['version'])
        for source_api in source_apis:
            source_version = source_api['version']
            if not source_version:
                continue
            if source_version in existing_versions:
                matching_blocks = False
                for apidoc_api in apidoc_docs[api_id]:
                    if apidoc_api['version'] == source_version and compare_api_blocks(source_api, apidoc_api):
                        matching_blocks = True
                        break
                if not matching_blocks:
                    api_desc = format_api_identifier(api_id)
                    location = f" at line {source_api['line_number']}" if source_api['line_number'] else ""
                    errors.append(
                        f"API {api_desc}{location} uses version {source_version} which already exists "
                        f"in _apidoc.js but with different content. Each version must be unique for this API."
                    )
    return errors

def check_for_duplicate_api_names(source_docs):
    # [Remaining function unchanged]
    errors = []
    seen_apis = {}
    for api_id, source_apis in source_docs.items():
        name, group = api_id
        if not name or not group:
            continue
        if api_id in seen_apis:
            first_line = seen_apis[api_id]
            for api_info in source_apis:
                location = f" at line {api_info['line_number']}" if api_info['line_number'] else ""
                errors.append(
                    f"Duplicate API definition {format_api_identifier(api_id)}{location}. "
                    f"First occurrence at line {first_line}. Each combination of apiName and apiGroup must be unique."
                )
        else:
            if source_apis and source_apis[0]['line_number']:
                seen_apis[api_id] = source_apis[0]['line_number']
    return errors

def compare_api_docs(source_docs, apidoc_docs):
    # [Remaining function unchanged]
    errors = []
    duplicate_name_errors = check_for_duplicate_api_names(source_docs)
    errors.extend(duplicate_name_errors)
    
    for api_id, api_infos in source_docs.items():
        for api_info in api_infos:
            if api_info['missing_fields']:
                missing = ", ".join(api_info['missing_fields'])
                api_desc = format_api_identifier(api_id)
                location = f" at line {api_info['line_number']}" if api_info['line_number'] else ""
                errors.append(
                    f"API {api_desc}{location} is missing mandatory fields: {missing}"
                )
            empty_fields = check_empty_fields(api_info)
            if empty_fields:
                empty = ", ".join(empty_fields)
                api_desc = format_api_identifier(api_id)
                location = f" at line {api_info['line_number']}" if api_info['line_number'] else ""
                errors.append(
                    f"API {api_desc}{location} has empty mandatory fields: {empty}"
                )
    
    duplicate_errors = check_for_duplicate_versions(source_docs, apidoc_docs)
    errors.extend(duplicate_errors)
    
    for api_id, source_apis in source_docs.items():
        if api_id not in apidoc_docs:
            continue
        highest_version = get_highest_version_for_api(api_id, apidoc_docs[api_id])
        for source_api in source_apis:
            source_version = source_api['version']
            if not source_version:
                continue
            api_desc = format_api_identifier(api_id)
            location = f" at line {source_api['line_number']}" if source_api['line_number'] else ""
            if compare_versions(source_version, highest_version) < 0:
                errors.append(
                    f"API {api_desc}{location} has version {source_version} which is lower than "
                    f"the highest version {highest_version} in _apidoc.js for this API. Version downgrade is not allowed."
                )
            for apidoc_api in apidoc_docs[api_id]:
                if source_version == apidoc_api['version']:
                    if source_api['path'] != apidoc_api['path']:
                        errors.append(
                            f"API {api_desc}{location} path has changed from '{apidoc_api['path']}' to '{source_api['path']}' "
                            f"but version remains {source_version}. Path changes require version updates."
                        )
                    if source_api['method'] != apidoc_api['method']:
                        errors.append(
                            f"API {api_desc}{location} method has changed from '{apidoc_api['method']}' to '{source_api['method']}' "
                            f"but version remains {source_version}. Method changes require version updates."
                        )
                    if not compare_api_blocks(source_api, apidoc_api):
                        diff = "\n".join(difflib.unified_diff(
                            sorted(apidoc_api['api_lines']), 
                            sorted(source_api['api_lines']), 
                            fromfile="_apidoc.js",
                            tofile="source.cpp",
                            lineterm=""
                        ))
                        if diff:
                            errors.append(
                                f"API {api_desc}{location} has been modified without updating the version:\n{diff}"
                            )
    return errors

def print_summary(source_docs, apidoc_docs, errors):
    # [Remaining function unchanged]
    source_count = sum(len(apis) for apis in source_docs.values())
    apidoc_count = sum(len(apis) for apis in apidoc_docs.values())
    print("\n=== APIDOC VALIDATION SUMMARY ===")
    print(f"Found {source_count} API endpoints in source file")
    print(f"Found {apidoc_count} API endpoints in _apidoc.js file")
    if errors:
        print(f"\nTotal errors found: {len(errors)}")
        for i, error in enumerate(errors):
            print(f"\nError {i+1}:")
            print(error)
        print("\nJenkins build failed: API documentation issues detected.")
    else:
        print("\nNo issues detected. API documentation is valid.")

if __name__ == "__main__":
    print("Checking APIDoc consistency and completeness...")
    
    # Perform preliminary check first
    preliminary_empty_check(SOURCE_FILE)
    
    # If preliminary check passes, proceed with the rest
    source_docs = extract_apidoc_blocks(SOURCE_FILE)
    apidoc_docs = extract_apidoc_blocks(APIDOC_FILE)
    
    errors = compare_api_docs(source_docs, apidoc_docs)
    print_summary(source_docs, apidoc_docs, errors)
    
    if errors:
        sys.exit(1)
    else:
        print("\nJenkins build passed: All API documentation is consistent and complete.")
        sys.exit(0)