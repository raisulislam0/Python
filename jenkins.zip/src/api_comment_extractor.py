#!/usr/bin/env python3
"""
API Documentation Comment Extractor

This script extracts apiDocJS comments from C++ source files, appends only
the changed API versions to the _apidoc.js file, and updates the version
in apidoc.json based on the latest @apiVersion in _apidoc.js.
"""

import os
import re
import json
import hashlib
from pathlib import Path
import argparse
from collections import defaultdict
import datetime

def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Extract apiDocJS comments, update _apidoc.js, and sync apidoc.json version")
    parser.add_argument('--root-dir', default='../', help='Root directory of the project')
    parser.add_argument('--recursive', '-r', action='store_true', help='Recursively search for source files')
    parser.add_argument('--output', default='_apidoc.js', help='Output file name for version history')
    parser.add_argument('--force', '-f', action='store_true', help='Force append even if versions unchanged')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    return parser.parse_args()

def extract_api_comments(file_path):
    """Extract apiDocJS comments from a file."""
    api_comments = []
    current_comment = []
    in_comment = False
    
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if '/**' in line and not in_comment:
                in_comment = True
                current_comment = [line]
            elif '*/' in line and in_comment:
                current_comment.append(line)
                comment_text = ''.join(current_comment)
                if '@api ' in comment_text:  # Only include apiDocJS comments
                    api_comments.append(comment_text)
                current_comment = []
                in_comment = False
            elif in_comment:
                current_comment.append(line)
    
    return api_comments

def extract_version_from_comment(comment):
    """Extract API version from a comment block."""
    version_match = re.search(r'@apiVersion\s+([0-9.]+)', comment)
    if version_match:
        return version_match.group(1)
    return None

def extract_endpoint_from_comment(comment):
    """Extract API endpoint from a comment block."""
    endpoint_match = re.search(r'@api\s+{([^}]+)}\s+([^\s]+)', comment)
    if endpoint_match:
        method = endpoint_match.group(1)
        path = endpoint_match.group(2)
        return f"{method} {path}"
    return None

def get_api_info(api_comments):
    """Get API information including endpoints and versions."""
    api_info = {}
    for comment in api_comments:
        endpoint = extract_endpoint_from_comment(comment)
        version = extract_version_from_comment(comment)
        
        if endpoint and version:
            api_info[endpoint] = {
                'version': version,
                'comment': comment
            }
    
    return api_info

def load_existing_api_info(apidoc_js_path):
    """Load existing API information from _apidoc.js file."""
    if not os.path.exists(apidoc_js_path):
        return {}
    
    existing_api_info = {}
    with open(apidoc_js_path, 'r', encoding='utf-8') as f:
        content = f.read()
        
    # Extract comment blocks from _apidoc.js
    comment_blocks = re.findall(r'/\*\*[\s\S]*?\*/', content)
    
    for comment in comment_blocks:
        endpoint = extract_endpoint_from_comment(comment)
        version = extract_version_from_comment(comment)
        
        if endpoint and version:
            existing_api_info[endpoint] = {
                'version': version,
                'comment': comment
            }
    
    return existing_api_info

def find_changed_endpoints(current_api_info, existing_api_info):
    """Identify endpoints with version changes or new endpoints."""
    changed_endpoints = {}
    
    # Find updated or new endpoints
    for endpoint, info in current_api_info.items():
        if endpoint not in existing_api_info or info['version'] != existing_api_info[endpoint]['version']:
            changed_endpoints[endpoint] = info
    
    # Find removed endpoints
    for endpoint in existing_api_info:
        if endpoint not in current_api_info:
            # Mark removed endpoints by setting to None
            changed_endpoints[endpoint] = None
    
    return changed_endpoints

def append_to_apidoc_js(apidoc_js_path, changed_api_info):
    """Append only changed API versions to the _apidoc.js file while preserving previous content."""
    # Read existing content if file exists
    existing_content = ""
    if os.path.exists(apidoc_js_path):
        with open(apidoc_js_path, 'r', encoding='utf-8') as f:
            existing_content = f.read()
    else:
        # If file doesn't exist, create header
        existing_content = "// API Documentation - Version History\n\n"
    
    # Only continue if there are changes to append
    changed_endpoints_count = len([ep for ep, info in changed_api_info.items() if info is not None])
    removed_endpoints_count = len([ep for ep, info in changed_api_info.items() if info is None])
    
    if changed_endpoints_count == 0 and removed_endpoints_count == 0:
        return 0
    
    # Group comments by version
    version_groups = defaultdict(list)
    for endpoint, info in changed_api_info.items():
        if info is not None:  # Skip removed endpoints
            version_groups[info['version']].append(info['comment'])
    
    # Create new content section with timestamp
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    
    new_content = f"\n\n// ===== Update: {timestamp} =====\n"
    
    if removed_endpoints_count > 0:
        new_content += f"\n// Removed Endpoints: {removed_endpoints_count}\n"
        for endpoint, info in changed_api_info.items():
            if info is None:
                new_content += f"// Removed: {endpoint}\n"
                
    for version, comments in sorted(version_groups.items()):
        new_content += f"\n// API Version {version}\n"
        new_content += "\n".join(comments)
        new_content += "\n"
    
    # Combine existing and new content
    combined_content = existing_content + new_content
    
    with open(apidoc_js_path, 'w', encoding='utf-8') as f:
        f.write(combined_content)
        
    return changed_endpoints_count + removed_endpoints_count

def get_latest_version_from_apidoc_js(apidoc_js_path):
    """Get the latest @apiVersion from the _apidoc.js file."""
    if not os.path.exists(apidoc_js_path):
        return None
    
    latest_version = None
    with open(apidoc_js_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Find all @apiVersion tags
    versions = re.findall(r'@apiVersion\s+([0-9.]+)', content)
    
    if not versions:
        return None
    
    # Convert versions to tuples for proper comparison (e.g., "1.10.0" > "1.9.0")
    version_tuples = [tuple(map(int, v.split('.'))) for v in versions]
    latest_version_tuple = max(version_tuples)
    latest_version = '.'.join(map(str, latest_version_tuple))
    
    return latest_version

def update_apidoc_json(root_dir, latest_version):
    """Update the version field in apidoc.json with the latest version."""
    apidoc_json_path = root_dir / 'apidoc.json'
    
    if not apidoc_json_path.exists():
        print(f"Warning: {apidoc_json_path} not found. Cannot update version.")
        return False
    
    # Read existing apidoc.json
    with open(apidoc_json_path, 'r', encoding='utf-8') as f:
        apidoc_data = json.load(f)
    
    # Update the version field if different
    if latest_version and apidoc_data.get('version') != latest_version:
        apidoc_data['version'] = latest_version
        with open(apidoc_json_path, 'w', encoding='utf-8') as f:
            json.dump(apidoc_data, f, indent=2)
            f.write('\n')  # Ensure file ends with a newline
        return True
    
    return False

def find_source_files(root_dir, recursive=False):
    """Find all C++ source files in the specified directory."""
    extensions = ['.cpp', '.cc', '.h', '.hpp']
    source_files = []
    
    if recursive:
        for root, _, files in os.walk(root_dir):
            for file in files:
                if any(file.endswith(ext) for ext in extensions):
                    source_files.append(os.path.join(root, file))
    else:
        for file in os.listdir(root_dir):
            if os.path.isfile(os.path.join(root_dir, file)) and any(file.endswith(ext) for ext in extensions):
                source_files.append(os.path.join(root_dir, file))
    
    return source_files

def main():
    """Main function."""
    args = parse_arguments()
    
    # Determine root directory dynamically based on script location
    script_dir = Path(__file__).resolve().parent  # Gets 'src' directory
    root_dir = script_dir.parent  # Moves one level up to root
    
    src_dir = root_dir / 'src'  # Ensure it correctly references 'src'
    if not src_dir.exists():
        raise FileNotFoundError(f"Source directory not found: {src_dir}")
    
    # Find all source files
    source_files = find_source_files(src_dir, args.recursive)
    
    if args.verbose:
        print(f"Found {len(source_files)} source files to process")
    
    # Extract API comments from all source files
    all_api_comments = []
    for file_path in source_files:
        if args.verbose:
            print(f"Processing {file_path}")
        file_comments = extract_api_comments(file_path)
        all_api_comments.extend(file_comments)
    
    if args.verbose:
        print(f"Extracted {len(all_api_comments)} API comment blocks")
    
    # Get API information
    current_api_info = get_api_info(all_api_comments)
    
    # Define the output directory and ensure it exists
    doc_container = root_dir / 'doc_container'
    doc_container.mkdir(parents=True, exist_ok=True)
    apidoc_js_path = doc_container / args.output
    
    # Load existing API info from _apidoc.js
    existing_api_info = load_existing_api_info(apidoc_js_path)
    
    # Find changed endpoints
    changed_api_info = find_changed_endpoints(current_api_info, existing_api_info)
    
    # Update _apidoc.js with changes if any
    if args.force or changed_api_info:
        if args.verbose:
            changed_count = len([ep for ep, info in changed_api_info.items() if info is not None])
            removed_count = len([ep for ep, info in changed_api_info.items() if info is None])
            print(f"Detected API changes: {changed_count} changed/new endpoints, {removed_count} removed endpoints")
        
        updated_count = append_to_apidoc_js(apidoc_js_path, changed_api_info)
        
        if updated_count > 0:
            print(f"Updated {apidoc_js_path} with {updated_count} API endpoint changes")
        else:
            print("No changes to API versions detected. _apidoc.js not updated.")
    else:
        if args.verbose:
            print("No API version changes detected, _apidoc.js remains unchanged")
        print("No changes to API versions detected. _apidoc.js not updated.")
    
    # Get the latest version from _apidoc.js and update apidoc.json
    latest_version = get_latest_version_from_apidoc_js(apidoc_js_path)
    if latest_version:
        if args.verbose:
            print(f"Latest API version found: {latest_version}")
        updated = update_apidoc_json(root_dir, latest_version)
        if updated:
            print(f"Updated apidoc.json version to {latest_version}")
        elif args.verbose:
            print(f"apidoc.json version already up-to-date with {latest_version}")
    else:
        print("No API versions found in _apidoc.js. apidoc.json version not updated.")

if __name__ == "__main__":
    main()